<div class="row">
    <div class="col-md-12">
        <section class="panel"> 
            <div class="panel-body">
 
<?php if( !empty ( $sucursales->id) ): ?>
    <div class="form-group">
        <label for="nombre" class="negrita">Codigo:</label> 
        <div>
            <input class="form-control" placeholder="001" required="required" name="codigo" type="text" id="codigo" value="<?php echo e($sucursales->codigo); ?>"> 
        </div>
    </div>
 
    <div class="form-group">
        <label for="domicilio" class="negrita">Domicilio:</label> 
        <div>
            <input class="form-control" placeholder="Cll # #-#" required="required" name="domicilio" type="text" id="domicilio" value="<?php echo e($sucursales->domicilio); ?>"> 
        </div>
    </div>
 
    <div class="form-group">
        <label for="telefono" class="negrita">Telefono:</label> 
        <div>
            <input class="form-control" placeholder="300000000" required="required" name="telefono" type="text" id="telefono" value="<?php echo e($sucursales->telefono); ?>"> 
        </div>
    </div>
<?php else: ?>
    <div class="form-group">
        <label for="codigo" class="negrita">Codigo:</label> 
        <div>
            <input class="form-control" placeholder="Codigo" required="required" name="codigo" type="text" id="codigo"> 
        </div>
    </div>
 
    <div class="form-group">
        <label for="domicilio" class="negrita">Domicilio:</label> 
        <div>
            <input class="form-control" placeholder="Cll # #-#" required="required" name="domicilio" type="text" id="domicilio"> 
        </div>
    </div>
 
    <div class="form-group">
        <label for="telefono" class="negrita">Telefono:</label> 
        <div>
            <input class="form-control" placeholder="300000000" required="required" name="telefono" type="text" id="telefono"> 
        </div>
    </div>
<?php endif; ?>
<button type="submit" class="btn btn-info">Guardar</button>

 <br>
 <br> 
            </div>
        </section>
    </div>
</div><?php /**PATH C:\xampp\htdocs\app\resources\views/admin/sucursales/frm/prt.blade.php ENDPATH**/ ?>